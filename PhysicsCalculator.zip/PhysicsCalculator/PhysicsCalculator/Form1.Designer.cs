﻿namespace PhysicsCalculator
{
    partial class FormPhysics_Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonMod = new System.Windows.Forms.Button();
            this.buttonSin = new System.Windows.Forms.Button();
            this.buttonAkar = new System.Windows.Forms.Button();
            this.buttonRad = new System.Windows.Forms.Button();
            this.button1x = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonPhi = new System.Windows.Forms.Button();
            this.buttonBagi = new System.Windows.Forms.Button();
            this.buttonCos = new System.Windows.Forms.Button();
            this.buttonBackspace = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonKali = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.buttonDelapan = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.buttonKurang = new System.Windows.Forms.Button();
            this.buttonEnam = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.buttonTambah = new System.Windows.Forms.Button();
            this.buttonTiga = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonSamaDengan = new System.Windows.Forms.Button();
            this.buttonTitik = new System.Windows.Forms.Button();
            this.button00 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonMod
            // 
            this.buttonMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMod.Location = new System.Drawing.Point(19, 128);
            this.buttonMod.Name = "buttonMod";
            this.buttonMod.Size = new System.Drawing.Size(75, 23);
            this.buttonMod.TabIndex = 1;
            this.buttonMod.Text = "MOD";
            this.buttonMod.UseVisualStyleBackColor = true;
            this.buttonMod.Click += new System.EventHandler(this.buttonMod_Click);
            // 
            // buttonSin
            // 
            this.buttonSin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSin.Location = new System.Drawing.Point(100, 128);
            this.buttonSin.Name = "buttonSin";
            this.buttonSin.Size = new System.Drawing.Size(75, 23);
            this.buttonSin.TabIndex = 2;
            this.buttonSin.Text = "SIN";
            this.buttonSin.UseVisualStyleBackColor = true;
            this.buttonSin.Click += new System.EventHandler(this.buttonSin_Click);
            // 
            // buttonAkar
            // 
            this.buttonAkar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAkar.Location = new System.Drawing.Point(181, 128);
            this.buttonAkar.Name = "buttonAkar";
            this.buttonAkar.Size = new System.Drawing.Size(75, 23);
            this.buttonAkar.TabIndex = 3;
            this.buttonAkar.Text = "√";
            this.buttonAkar.UseVisualStyleBackColor = true;
            this.buttonAkar.Click += new System.EventHandler(this.buttonAkar_Click);
            // 
            // buttonRad
            // 
            this.buttonRad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRad.Location = new System.Drawing.Point(262, 128);
            this.buttonRad.Name = "buttonRad";
            this.buttonRad.Size = new System.Drawing.Size(75, 23);
            this.buttonRad.TabIndex = 4;
            this.buttonRad.Text = "ROUND";
            this.buttonRad.UseVisualStyleBackColor = true;
            this.buttonRad.Click += new System.EventHandler(this.buttonRad_Click);
            // 
            // button1x
            // 
            this.button1x.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1x.Location = new System.Drawing.Point(262, 157);
            this.button1x.Name = "button1x";
            this.button1x.Size = new System.Drawing.Size(75, 23);
            this.button1x.TabIndex = 8;
            this.button1x.Text = "1/x";
            this.button1x.UseVisualStyleBackColor = true;
            this.button1x.Click += new System.EventHandler(this.button1x_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(181, 157);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 7;
            this.button6.Text = "!";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // buttonE
            // 
            this.buttonE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonE.Location = new System.Drawing.Point(100, 157);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(75, 23);
            this.buttonE.TabIndex = 6;
            this.buttonE.Text = "e^x";
            this.buttonE.UseVisualStyleBackColor = true;
            this.buttonE.Click += new System.EventHandler(this.buttonE_Click);
            // 
            // buttonPhi
            // 
            this.buttonPhi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPhi.Location = new System.Drawing.Point(19, 157);
            this.buttonPhi.Name = "buttonPhi";
            this.buttonPhi.Size = new System.Drawing.Size(75, 23);
            this.buttonPhi.TabIndex = 5;
            this.buttonPhi.Text = "π";
            this.buttonPhi.UseVisualStyleBackColor = true;
            this.buttonPhi.Click += new System.EventHandler(this.buttonPhi_Click);
            // 
            // buttonBagi
            // 
            this.buttonBagi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBagi.Location = new System.Drawing.Point(262, 186);
            this.buttonBagi.Name = "buttonBagi";
            this.buttonBagi.Size = new System.Drawing.Size(75, 23);
            this.buttonBagi.TabIndex = 12;
            this.buttonBagi.Text = "/";
            this.buttonBagi.UseVisualStyleBackColor = true;
            this.buttonBagi.Click += new System.EventHandler(this.buttonBagi_Click);
            // 
            // buttonCos
            // 
            this.buttonCos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCos.Location = new System.Drawing.Point(181, 186);
            this.buttonCos.Name = "buttonCos";
            this.buttonCos.Size = new System.Drawing.Size(75, 23);
            this.buttonCos.TabIndex = 11;
            this.buttonCos.Text = "COS";
            this.buttonCos.UseVisualStyleBackColor = true;
            this.buttonCos.Click += new System.EventHandler(this.buttonCos_Click);
            // 
            // buttonBackspace
            // 
            this.buttonBackspace.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBackspace.Location = new System.Drawing.Point(100, 186);
            this.buttonBackspace.Name = "buttonBackspace";
            this.buttonBackspace.Size = new System.Drawing.Size(75, 23);
            this.buttonBackspace.TabIndex = 10;
            this.buttonBackspace.Text = "BackSpace";
            this.buttonBackspace.UseVisualStyleBackColor = true;
            this.buttonBackspace.Click += new System.EventHandler(this.buttonSpace_Click);
            // 
            // buttonC
            // 
            this.buttonC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonC.Location = new System.Drawing.Point(19, 186);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(75, 23);
            this.buttonC.TabIndex = 9;
            this.buttonC.Text = "C";
            this.buttonC.UseVisualStyleBackColor = true;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // buttonKali
            // 
            this.buttonKali.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKali.Location = new System.Drawing.Point(262, 215);
            this.buttonKali.Name = "buttonKali";
            this.buttonKali.Size = new System.Drawing.Size(75, 23);
            this.buttonKali.TabIndex = 16;
            this.buttonKali.Text = "*";
            this.buttonKali.UseVisualStyleBackColor = true;
            this.buttonKali.Click += new System.EventHandler(this.buttonKali_Click);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(181, 215);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 15;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // buttonDelapan
            // 
            this.buttonDelapan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDelapan.Location = new System.Drawing.Point(100, 215);
            this.buttonDelapan.Name = "buttonDelapan";
            this.buttonDelapan.Size = new System.Drawing.Size(75, 23);
            this.buttonDelapan.TabIndex = 14;
            this.buttonDelapan.Text = "8";
            this.buttonDelapan.UseVisualStyleBackColor = true;
            this.buttonDelapan.Click += new System.EventHandler(this.buttonDelapan_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(19, 215);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 13;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // buttonKurang
            // 
            this.buttonKurang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKurang.Location = new System.Drawing.Point(262, 244);
            this.buttonKurang.Name = "buttonKurang";
            this.buttonKurang.Size = new System.Drawing.Size(75, 23);
            this.buttonKurang.TabIndex = 20;
            this.buttonKurang.Text = "-";
            this.buttonKurang.UseVisualStyleBackColor = true;
            this.buttonKurang.Click += new System.EventHandler(this.buttonKurang_Click);
            // 
            // buttonEnam
            // 
            this.buttonEnam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEnam.Location = new System.Drawing.Point(181, 244);
            this.buttonEnam.Name = "buttonEnam";
            this.buttonEnam.Size = new System.Drawing.Size(75, 23);
            this.buttonEnam.TabIndex = 19;
            this.buttonEnam.Text = "6";
            this.buttonEnam.UseVisualStyleBackColor = true;
            this.buttonEnam.Click += new System.EventHandler(this.buttonEnam_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(100, 244);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 18;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(19, 244);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 17;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonTambah
            // 
            this.buttonTambah.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTambah.Location = new System.Drawing.Point(262, 273);
            this.buttonTambah.Name = "buttonTambah";
            this.buttonTambah.Size = new System.Drawing.Size(75, 23);
            this.buttonTambah.TabIndex = 24;
            this.buttonTambah.Text = "+";
            this.buttonTambah.UseVisualStyleBackColor = true;
            this.buttonTambah.Click += new System.EventHandler(this.buttonTambah_Click);
            // 
            // buttonTiga
            // 
            this.buttonTiga.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTiga.Location = new System.Drawing.Point(181, 273);
            this.buttonTiga.Name = "buttonTiga";
            this.buttonTiga.Size = new System.Drawing.Size(75, 23);
            this.buttonTiga.TabIndex = 23;
            this.buttonTiga.Text = "3";
            this.buttonTiga.UseVisualStyleBackColor = true;
            this.buttonTiga.Click += new System.EventHandler(this.buttonTiga_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(100, 273);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 22;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(19, 273);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonSamaDengan
            // 
            this.buttonSamaDengan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSamaDengan.Location = new System.Drawing.Point(262, 302);
            this.buttonSamaDengan.Name = "buttonSamaDengan";
            this.buttonSamaDengan.Size = new System.Drawing.Size(75, 23);
            this.buttonSamaDengan.TabIndex = 28;
            this.buttonSamaDengan.Text = "=";
            this.buttonSamaDengan.UseVisualStyleBackColor = true;
            this.buttonSamaDengan.Click += new System.EventHandler(this.buttonSamaDengan_Click);
            // 
            // buttonTitik
            // 
            this.buttonTitik.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTitik.Location = new System.Drawing.Point(181, 302);
            this.buttonTitik.Name = "buttonTitik";
            this.buttonTitik.Size = new System.Drawing.Size(75, 23);
            this.buttonTitik.TabIndex = 27;
            this.buttonTitik.Text = ".";
            this.buttonTitik.UseVisualStyleBackColor = true;
            this.buttonTitik.Click += new System.EventHandler(this.buttonTitik_Click);
            // 
            // button00
            // 
            this.button00.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button00.Location = new System.Drawing.Point(100, 302);
            this.button00.Name = "button00";
            this.button00.Size = new System.Drawing.Size(75, 23);
            this.button00.TabIndex = 26;
            this.button00.Text = "00";
            this.button00.UseVisualStyleBackColor = true;
            this.button00.Click += new System.EventHandler(this.button00_Click);
            // 
            // button0
            // 
            this.button0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button0.Location = new System.Drawing.Point(19, 302);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(75, 23);
            this.button0.TabIndex = 25;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // txtInput
            // 
            this.txtInput.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInput.Location = new System.Drawing.Point(19, 38);
            this.txtInput.Multiline = true;
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(318, 45);
            this.txtInput.TabIndex = 29;
            // 
            // FormPhysics_Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 335);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.buttonSamaDengan);
            this.Controls.Add(this.buttonTitik);
            this.Controls.Add(this.button00);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.buttonTambah);
            this.Controls.Add(this.buttonTiga);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonKurang);
            this.Controls.Add(this.buttonEnam);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.buttonKali);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.buttonDelapan);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.buttonBagi);
            this.Controls.Add(this.buttonCos);
            this.Controls.Add(this.buttonBackspace);
            this.Controls.Add(this.buttonC);
            this.Controls.Add(this.button1x);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.buttonE);
            this.Controls.Add(this.buttonPhi);
            this.Controls.Add(this.buttonRad);
            this.Controls.Add(this.buttonAkar);
            this.Controls.Add(this.buttonSin);
            this.Controls.Add(this.buttonMod);
            this.Name = "FormPhysics_Calculator";
            this.Text = "Physics Calculator";
            this.Load += new System.EventHandler(this.FormPhysics_Calculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonMod;
        private System.Windows.Forms.Button buttonSin;
        private System.Windows.Forms.Button buttonAkar;
        private System.Windows.Forms.Button buttonRad;
        private System.Windows.Forms.Button button1x;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonPhi;
        private System.Windows.Forms.Button buttonBagi;
        private System.Windows.Forms.Button buttonCos;
        private System.Windows.Forms.Button buttonBackspace;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button buttonKali;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button buttonDelapan;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button buttonKurang;
        private System.Windows.Forms.Button buttonEnam;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button buttonTambah;
        private System.Windows.Forms.Button buttonTiga;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonSamaDengan;
        private System.Windows.Forms.Button buttonTitik;
        private System.Windows.Forms.Button button00;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.TextBox txtInput;
    }
}

